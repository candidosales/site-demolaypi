jQuery RWD Image Maps
==============================

### Allows image maps to be used in a responsive design by recalculating the area coordinates to match the actual image size on load and window.resize

* * *

Usage:

$('img[usemap]').rwdImageMaps();

* * *

Demo:

http://www.mattstow.com/experiment/responsive-image-maps/rwd-image-maps.html