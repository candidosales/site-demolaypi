/* Use this script if you need to support IE 7 and IE 6. */

window.onload = function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
			'icon-play' : '&#xe001;',
			'icon-wordpress' : '&#xe006;',
			'icon-twitter' : '&#xe000;',
			'icon-facebook' : '&#xe002;',
			'icon-html5' : '&#xe003;',
			'icon-file-excel' : '&#xe004;',
			'icon-file-word' : '&#xe005;',
			'icon-file-pdf' : '&#xe007;',
			'icon-pencil' : '&#xe008;',
			'icon-file' : '&#xe009;',
			'icon-phone' : '&#xe00a;',
			'icon-mail' : '&#xe00b;',
			'icon-calendar' : '&#xe00c;',
			'icon-book' : '&#xe00d;',
			'icon-file-powerpoint' : '&#xe00e;',
			'icon-locked' : '&#xe00f;'
		},
		els = document.getElementsByTagName('*'),
		i, attr, html, c, el;
	for (i = 0; i < els.length; i += 1) {
		el = els[i];
		attr = el.getAttribute('data-icon');
		if (attr) {
			addIcon(el, attr);
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c) {
			addIcon(el, icons[c[0]]);
		}
	}
};